using Terraria.ModLoader;

namespace That1opWeapon
{
	class That1opWeapon : Mod
	{
		public That1opWeapon()
		{
		}
	}
}
